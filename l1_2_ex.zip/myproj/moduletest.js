import Circle from './circle.js';

var circle = new Circle(10);

console.log(circle.area());