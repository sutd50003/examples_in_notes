const pi = 3.14159
const e = 2.71828

export {pi, e};